# ---------------- Step 1: Imports ----------------
import os
import zipfile
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.preprocessing.image import load_img, img_to_array

# ---------------- Step 2: Extract dataset ----------------
zip_path = "dataset2.0.zip"
with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    zip_ref.extractall(".")
print("✅ dataset2.0.zip extracted successfully!")

# ---------------- Step 3: Load all images ----------------
IMG_SIZE = (128, 128)
dataset_path = "dataset2.0"
all_images = []

# Loop over each image file in dataset2.0
for filename in os.listdir(dataset_path):
    if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
        img_path = os.path.join(dataset_path, filename)
        img = load_img(img_path, target_size=IMG_SIZE)  # resize
        img_array = img_to_array(img) / 255.0          # normalize
        all_images.append(img_array)

all_images = np.array(all_images)
print(f"✅ Loaded {len(all_images)} images")

# ---------------- Step 4: Build Autoencoder ----------------
input_img = Input(shape=(128, 128, 3))

# Encoder
x = Conv2D(32, (3,3), activation='relu', padding='same')(input_img)
x = MaxPooling2D((2,2), padding='same')(x)
x = Conv2D(64, (3,3), activation='relu', padding='same')(x)
x = MaxPooling2D((2,2), padding='same')(x)
x = Conv2D(128, (3,3), activation='relu', padding='same')(x)
encoded = MaxPooling2D((2,2), padding='same')(x)

# Decoder
x = Conv2D(128, (3,3), activation='relu', padding='same')(encoded)
x = UpSampling2D((2,2))(x)
x = Conv2D(64, (3,3), activation='relu', padding='same')(x)
x = UpSampling2D((2,2))(x)
x = Conv2D(32, (3,3), activation='relu', padding='same')(x)
x = UpSampling2D((2,2))(x)
decoded = Conv2D(3, (3,3), activation='sigmoid', padding='same')(x)

autoencoder = Model(input_img, decoded)
autoencoder.compile(optimizer=Adam(), loss='mse')
autoencoder.summary()

# ---------------- Step 5: Train Autoencoder ----------------
history = autoencoder.fit(
    all_images, all_images,
    epochs=20,
    batch_size=16,
    shuffle=True
)

# ---------------- Step 6: Reconstruct and Save ----------------
os.makedirs("reconstructed", exist_ok=True)
reconstructed = autoencoder.predict(all_images)

for i, img in enumerate(reconstructed):
    img_uint8 = np.clip(img * 255, 0, 255).astype(np.uint8)
    plt.imsave(f"reconstructed/recon_{i}.png", img_uint8)

print(f"✅ All {len(reconstructed)} images saved in 'reconstructed/'")
